import java.time.LocalTime;  
import org.json.JSONObject;
import org.json.JSONString;  
import org.json.XML; 
import java.lang.management.ManagementFactory;
import java.util.HashMap;
import java.sql.*;
import java.io.*;
import java.util.Iterator;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;  
import java.time.temporal.ChronoUnit; 
import java.text.DecimalFormat;
@WebServlet(urlPatterns = {"/Loader"})
class Loader  extends HttpServlet 
{
    int j;
    String tab = " ";
    String tempNow="";
    public void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException 
    {
        try
        {
            LocalTime start = LocalTime.now();
            int core = Runtime.getRuntime().availableProcessors();  
            JSONObject js = new JSONObject(request.getParameter("json"));
            int limit =Integer.parseInt(request.getParameter("count"));
           
            tab +="<tr><td>"+limit+"</td>";
            tab +="<td>"+start+"</td>";
            ExecutorService executor = Executors.newFixedThreadPool(core);
            for(int i = 0; i < 4; i++) 
            {            
                executor.execute(new Runnable() 
                {
                    @Override
                    public void run() 
                    {
                        try
                        {
                            for (j=0; ; j++) 
                            {        
                                Iterator<?> keys = js.keys();
                                while( keys.hasNext() ) 
                                {
                                    String key = (String)keys.next();
                                    js.put(key,new Integer(j));                  
                                }                                                           
                            }
                        }
                        catch (Exception e) 
                        {
                            
                        }
                    }
                });
            }
             DecimalFormat df = new DecimalFormat("#.######");
            executor.awaitTermination(1000, TimeUnit.MILLISECONDS); 
            LocalTime end = LocalTime.now();   
            executor.shutdown();            
            tab +="<td>"+end+"</td>";
            //long minutes = ChronoUnit.MILLIS.between(start, end);                  
            tab +="<td>"+j+"</td>"; 
             double res =1000.0/j;            
            tab +="<td>"+df.format(res)+"</td></tr>";            
            String s = new String(js.toString());
            response.setContentType("text/html");              
            response.getWriter().write(tab);   

        }
        catch (Exception e) {
            
        }
    }
}
//https://dzone.com/articles/java-callable-future-understanding


