import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;   
import java.util.Timer;
import java.util.Iterator;
import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
 import org.json.JSONObject; 
@WebServlet(urlPatterns = {"/Check"})
public class Check extends HttpServlet  
{

  Thread searcher;
  JSONObject js;
  int limit;
  int k = 1;
  String message;
    public void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException 
    {
        PrintWriter out = response.getWriter();
        try 
        {             
     
          Loader a = new Loader();
          a.doPost(request,response);                            
          // RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
          // rd.forward(request,response);
        }
        catch(Exception e)
        {
         response.getWriter().write(e+" thiss");
        } 
    }
}