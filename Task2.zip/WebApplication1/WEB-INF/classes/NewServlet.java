/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
 import org.json.JSONObject;  
/**
 *
 * @author gowtham-pt1690
 */
@WebServlet(urlPatterns = {"/NewServlet"})
public class NewServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    public void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException 
{
    PrintWriter out = response.getWriter();
     JSONObject json = new JSONObject();
    try{
	
		response.setContentType("text/html");
		//out.print("<html><body>");
		
		Enumeration paramNames = request.getParameterNames();		
//		out.print("<h1> Your Order...</h1>");
//		out.println("<table border=1 cellpadding = 5 cellspacing = 5>");
//		out.println("<tr> <th>Parameter Name</th>" +"<th>Parameter Value</th></tr>");	
		while(paramNames.hasMoreElements()) 
		{
//			String paramName = (String)paramNames.nextElement();
//			out.print("<tr><td>" + paramName + "\n<td>");
//			String[] paramValues = request.getParameterValues(paramName);
//			if (paramValues.length == 1) 
//			{
//				String paramValue = paramValues[0];
//				if (paramValue.length() == 0)
//					out.println("No Value");
//				else
//					out.println(paramValue);
//			} 
//			else 
//			{
//				out.println("<ul>");
//				for(int i=0; i<paramValues.length; i++) 
//				{
//					out.println("<li>" + paramValues[i] + "</li>");
//				}
//				out.println("</ul>");
//			}
                     String param=(String)paramNames.nextElement();
                     String value=request.getParameter(param);
                     //out.println("Parameter Name is '"+param+"' and Parameter Value is '"+value+"'");
                   if (!param.equals("no_of_events")) {
                     json.put(value,"");
                 }
		}
              
                out.print(json);
	//out.println("</table></body></html>");
    }
    catch(Exception e)
    {
        out.print(e);
    }
}
}
