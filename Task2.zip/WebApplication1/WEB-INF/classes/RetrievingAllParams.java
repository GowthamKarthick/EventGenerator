import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.Enumeration;
import javax.servlet.annotation.WebServlet;
 import org.json.JSONObject;    

public class RetrievingAllParams extends HttpServlet 
{
	public void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException 
{
    PrintWriter out = response.getWriter();
     JSONObject json = new JSONObject();
    try{
	
		response.setContentType("text/html");
		out.print("<html><body>");
		
		Enumeration paramNames = request.getParameterNames();		
//		out.print("<h1> Your Order...</h1>");
//		out.println("<table border=1 cellpadding = 5 cellspacing = 5>");
//		out.println("<tr> <th>Parameter Name</th>" +"<th>Parameter Value</th></tr>");	
		while(paramNames.hasMoreElements()) 
		{
//			String paramName = (String)paramNames.nextElement();
//			out.print("<tr><td>" + paramName + "\n<td>");
//			String[] paramValues = request.getParameterValues(paramName);
//			if (paramValues.length == 1) 
//			{
//				String paramValue = paramValues[0];
//				if (paramValue.length() == 0)
//					out.println("No Value");
//				else
//					out.println(paramValue);
//			} 
//			else 
//			{
//				out.println("<ul>");
//				for(int i=0; i<paramValues.length; i++) 
//				{
//					out.println("<li>" + paramValues[i] + "</li>");
//				}
//				out.println("</ul>");
//			}
                     String param=(String)paramNames.nextElement();
                     String value=request.getParameter(param);
                     //out.println("Parameter Name is '"+param+"' and Parameter Value is '"+value+"'");
                    if (!param.equals("no_of_events")) {
                     json.put(value,"");
                 }
                    
		}
                out.print(json);
	out.println("</table></body></html>");
    }
    catch(Exception e)
    {
        out.print(e);
    }
}
}